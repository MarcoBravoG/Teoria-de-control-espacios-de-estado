%%%%% GR�FICAS DE LOS POLINOMIOS, QUE SE OBTIENE POR EXPERIMENTACI�N, FUERZAS vs. RPM voltajes vs. RPM %%%%%%%%

Wx=-600:1:800;
Frotorl=-3.48e-12*Wx.^5+1.095e-9*Wx.^4+4.123e-6*Wx.^3-1.632e-4*Wx.^2+9.544e-2*Wx;
figure(1);plot(Wx,Frotorl);grid;
title('Frotor vs RPM');
%ginput(l)
Wy=-1500:1:2000;
Ftaill=-3.10e-14*Wy.^5-1.595e-11*Wy.^4+2.511e-7*Wy.^3-1.808e-4*Wy.^2+0.0801*Wy;
figure(2);plot(Wy,Ftaill);grid;
title('Ftail vs RPM1');
%ginput(1)
uv=-1:0.1:1
Wv=90.99*uv.^6+599.73*uv.^5-129.26*uv.^4-1238.64*uv.^3+63.45*uv.^2+1283.41*uv;
figure(3);plot(uv,Wv);grid;
title('Uv vs RPM1');
uh=-1:0.1:1
Wh=2020*uh.^5-194.69*uh.^4-4283.15*uh.^3+262.27*uh.^2+3796.83*uh;
figure(4);plot(uh,Wh);grid;
title('Uh vs RPM1');