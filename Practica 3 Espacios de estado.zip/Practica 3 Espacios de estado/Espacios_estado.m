clc
clear all

%%%%%% ESPACIO DE ESTADOS %%%%%%% 
%%%%%% VARIABLES DE ESTADO => Pitch, Yaw, dPitch, dYaw, Tao1, Tao2, Mr => Matriz A(7X7)
%%%%%% ENTRADAS u1, u2  => Matriz B (2X7)
%%%%%% SALIDAS Pitch, Yaw  => Matriz C (2X7)
A=[0 1 0 0 0 0 0;-4.705 -0.0882 0 0 0 1.9266 0;0 0 0 1 0 0 0;0 0 0 -5 -45 1.6 4.5;0 0 0 0 -0.5 0.0133 0;0 0 0 0 0 -1 0;0 0 0 0 0 0 -1]
B=[0 0;0 0;0 0;0 0;0 0;1 0;0 0.8]
C=[1 0 0 0 0 0 0;0 1 0  0 0 0 0;0 0 1 0 0 0 0;0 0 0 1 0 0 0;0 0 0 0 1 0 0;0 0 0 0 0 1 0;0 0 0 0 0 0 1]
D=[0 0;0 0;0 0;0 0;0 0;0 0;0 0] 
%% %%%%POLOS%%%%
POLOS=eig(A)
POLOS_1=(POLOS/1.7)- 0.5
%% %%%%CONTROLADOR%%%%%
K=place(A,B,POLOS_1)
%% adecuador 
adq=pinv((D-(C-D*K)*pinv(A-B*K)*B))