clc
clear all

%%%%%% ESPACIO DE ESTADOS %%%%%%% 
%%%%%% VARIABLES DE ESTADO => Pitch, Yaw, dPitch, dYaw, Tao1, Tao2, Mr => Matriz A(7X7)
%%%%%% ENTRADAS u1, u2  => Matriz B (2X7)
%%%%%% SALIDAS Pitch, Yaw  => Matriz C (2X7)
A=[0 1 0 0 0 0 0;-4.705 -0.0882 0 0 0 1.9266 0;0 0 0 1 0 0 0;0 0 0 -5 -45 1.6 4.5;0 0 0 0 -0.5 0.0133 0;0 0 0 0 0 -1 0;0 0 0 0 0 0 -1]
B=[0 0;0 0;0 0;0 0;0 0;1 0;0 0.8]
C=[1 0 0 0 0 0 0;0 1 0  0 0 0 0;0 0 1 0 0 0 0;0 0 0 1 0 0 0;0 0 0 0 1 0 0;0 0 0 0 0 1 0;0 0 0 0 0 0 1]
D=[0 0;0 0;0 0;0 0;0 0;0 0;0 0] 
%% %%%%POLOS%%%%
POLOS=eig(A)
POLOS_1=(POLOS/1.7)- 0.5
%% %%%%CONTROLADOR%%%%%
K=place(A,B,POLOS_1)
%% adecuador 
adq=pinv((D-(C-D*K)*pinv(A-B*K)*B))


%% FUNCIONES DE TRANSFERENCIA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%     FUNCI�N DE TRANSFERENCIA 11 
num_1=[0.1441]
den_1=[0.0748 0.07493 0.3126 0.2784]
TF_1=tf(num_1,den_1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%     FUNCI�N DE TRANSFERENCIA 21
num_3=[-0.101 -0.029]
den_3=[0.04 0.075 0.038 0.006 0]
TF_3=tf(num_3,den_3)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%     FUNCI�N DE TRANSFERENCIA 22
num_4=[0.0579]
den_4=[0.021 0.13 0.11 0]
TF_4=tf(num_4,den_4)

%%%%%%%%%%%%   DISE�O DEL DESACOPLADOR   %%%%%%%%%%%%  
K1=[num_1 0; -0.029 num_4]
lamda= K1.*inv(K1)'
D21= -(TF_3/TF_4)

num_21 = D21.num{1}
den_21= D21.den{1}